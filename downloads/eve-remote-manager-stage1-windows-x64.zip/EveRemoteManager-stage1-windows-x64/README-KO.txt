EVE Remote Manager - Stage 1
================================

현재 버전은 EVE 창 탐지와 원격 PC 상태 확인용 1단계 프로토타입입니다.
화면 미리보기와 원격 마우스/키보드 제어는 아직 제공하지 않습니다.

요구 사항
- Windows 10/11 x64
- .NET 8 Desktop Runtime
- Agent PC에는 ASP.NET Core Runtime 8도 필요합니다.

실행
1. EVE를 실행할 원격 PC에서 Agent\EveRemote.Agent.exe를 실행합니다.
2. 메인 PC의 Controller\appsettings.json에서 Agent Address를 원격 PC 주소로 수정합니다.
   예: http://192.168.0.20:5081
3. 메인 PC에서 Controller\EveRemote.Controller.exe를 실행합니다.

주의
- 이 1단계 통신은 TLS가 없는 개발용 HTTP/2입니다.
- 인터넷에 Agent 5081 포트를 직접 공개하지 마세요.
- 신뢰할 수 있는 LAN 또는 Tailscale/WireGuard 안에서만 시험하세요.
- 자동화, 매크로, 반복 입력 및 입력 브로드캐스팅은 지원하지 않습니다.

문서
https://habang2222.github.io/development/eve_online_어짜구/
