@echo off
cd /d "%~dp0Controller"
start "EVE Remote Controller" EveRemote.Controller.exe
