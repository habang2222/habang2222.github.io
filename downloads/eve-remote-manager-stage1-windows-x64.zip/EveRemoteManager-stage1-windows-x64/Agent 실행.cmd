@echo off
cd /d "%~dp0Agent"
start "EVE Remote Agent" EveRemote.Agent.exe
